import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import warnings
warnings.filterwarnings('ignore')


plt.rcParams['font.family'] = 'WenQuanYi Micro Hei'
plt.rcParams['font.size'] = 12
plt.rcParams['axes.unicode_minus'] = False

# ==============================================================================
#  Step 1: 数据准备和预处理（读取沪深300+中证500成分股数据）
# ==============================================================================
# 读取数据（需确保TRD_Dalyr.xlsx包含Stkcd/Trddt/Dretwd/流通市值字段）
# ==================== 步骤1：正确读取数据 ====================
def read_data_correctly(filepath):
    """
    简单版本：直接使用header=1读取
    """
    try:
        df = pd.read_excel(filepath, sheet_name='sheet1', header=0, skiprows=[1, 2])
        
        print(f"✓ 成功读取数据（使用英文表头）")
        print(f"  数据形状: {df.shape}")
        
        # 查看列名
        print(f"  原始列名: {df.columns.tolist()}")
        
        return df
        
    except Exception as e:
        print(f"读取失败: {e}")
        return None


# 读取数据
print("="*80)
print("开始读取数据...")
df = read_data_correctly('TRD_Dalyr.xlsx')

if df is None:
    print("数据读取失败，请检查文件路径和格式")
    exit()

print("\n" + "="*80)
print("数据基本信息：")
print(f"数据形状：{df.shape}")
print(f"数据类型统计:{df.dtypes}")
print(f"列名：{df.columns.tolist()}")
print(f"数据期间：{df['Trddt'].min()} 到 {df['Trddt'].max()}")
print(f"股票数量：{df['Stkcd'].nunique()}")
print(f"总记录数：{len(df)}")
print("\n前5行数据：")
print(df.head())

# ==================== 步骤2：数据预处理 ====================
# 确保数据按股票代码和日期排序
df = df.sort_values(['Stkcd', 'Trddt']).reset_index(drop=True)

# 添加年月标记，用于月度分组
df['year_month'] = pd.to_datetime(df['Trddt'], errors='coerce').dt.to_period('M')

print("\n" + "="*80)
print("数据预处理完成！")

# ==============================================================================
#  Step 2: 计算3个因子（MAX/Past Performance/Volatility）
# ==============================================================================
def calculate_all_factors(df):
    """计算3个因子：
    1. MAX: 过去20个交易日最高日收益率
    2. Past Performance: 过去3个月（约60个交易日）持有期收益率
    3. Volatility: 过去20个交易日日收益率标准差
    """
    df = df.sort_values(['Stkcd', 'Trddt']).reset_index(drop=True)
    
    # 按股票分组计算因子
    def calc_factors_per_stock(group):
        group = group.sort_values('Trddt')
        # 1. MAX因子（过去20日最高收益率）
        group['MAX'] = group['Dretwd'].rolling(window=20, min_periods=15).max()
        
        # 2. Past Performance因子（过去3个月持有期收益率，约60个交易日）
        # 使用apply方法计算滚动窗口的累积乘积
        def rolling_prod(series):
            return np.prod(1 + series) - 1
        
        group['Past_Perf'] = group['Dretwd'].rolling(window=60, min_periods=45).apply(
            rolling_prod, raw=True
        )
        
        # 3. Volatility因子（过去20日收益率标准差）
        group['Volatility'] = group['Dretwd'].rolling(window=20, min_periods=15).std()
        return group
    
    df_with_factors = df.groupby('Stkcd').apply(calc_factors_per_stock).reset_index(drop=True)
    return df_with_factors

# 计算所有因子
df_processed = calculate_all_factors(df)
print("\n3个因子计算完成")
print(f"有效因子记录数：{df_processed[['MAX', 'Past_Perf', 'Volatility']].notna().sum(axis=0)}")

# ==============================================================================
#  Step 3: 月度多空组合构建（等权重，每月调整，支持3个因子）
# 核心修正：年化波动率=月波动率×√12，夏普比率=年化收益率/年化波动率
# ==============================================================================
def construct_monthly_portfolios(df, factor_name):
    """
    基于指定因子构建月度多空组合（等权重）
    factor_name: 可选值 -> 'MAX'/'Past_Perf'/'Volatility'
    关键计算逻辑：
    - 月波动率 = 当月日度收益率标准差
    - 年化波动率 = 月波动率 × √12
    - 年化收益率 = 月度收益率年化（累乘）
    - 夏普比率 = 年化收益率 / 年化波动率（无风险利率=0）
    """
    portfolio_results = []
    all_months = sorted(df['year_month'].unique())  # 所有月份（排序）
    
    for i in range(1, len(all_months)):
        group_month = all_months[i-1]  # 分组月份（t月月末因子值）
        return_month = all_months[i]   # 收益计算月份（t+1月）
        
        # 1. 获取分组数据（t月月末因子值，剔除缺失值）
        month_end_data = df[df['year_month'] == group_month].groupby('Stkcd').last().reset_index()
        month_end_data = month_end_data[['Stkcd', factor_name]].dropna()
        if len(month_end_data) < 50:  # 确保有足够股票分组
            continue
        
        # 2. 按因子值分成5组（Q1=最低20%，Q5=最高20%）
        month_end_data['quantile'] = pd.qcut(
            month_end_data[factor_name], 5, labels=[1,2,3,4,5], duplicates='drop'
        )
        
        # 3. 获取t+1月日度收益率数据
        next_month_data = df[df['year_month'] == return_month][['Stkcd', 'Trddt', 'Dretwd']]
        if len(next_month_data) == 0:
            continue
        
        # ==========================================================================
        # 计算1：各组月度收益率（仿照原文档高亮代码逻辑）
        # ==========================================================================
        daily_returns = []
        for date in next_month_data['Trddt'].unique():
            date_data = next_month_data[next_month_data['Trddt'] == date]
            merged_data = pd.merge(date_data, month_end_data[['Stkcd', 'quantile']], on='Stkcd')
            if len(merged_data) > 0:
                group_ret = merged_data.groupby('quantile')['Dretwd'].mean()  # 等权日收益
                for q, ret in group_ret.items():
                    daily_returns.append({'date': date, 'quantile': q, 'return': ret})
        daily_returns_df = pd.DataFrame(daily_returns)
        if len(daily_returns_df) == 0:
            continue
        
        # 月度收益率（日收益累乘）
        monthly_return = {}
        for q in [1,5]:  # 仅关注Q1（空头）和Q5（多头）
            q_ret = daily_returns_df[daily_returns_df['quantile'] == q]['return']
            monthly_return[f'Q{q}'] = (1 + q_ret).prod() - 1 if len(q_ret) > 0 else 0
        long_short_return = monthly_return['Q5'] - monthly_return['Q1']  # 多空收益
        
        # ==========================================================================
        # 计算2：各组年化波动率（严格按要求：月波动率 × √12）
        # 月波动率 = 当月日度收益率的标准差
        # ==========================================================================
        monthly_vol = {}  # 存储当月各组年化波动率
        for q in [1,5]:
            q_daily_ret = daily_returns_df[daily_returns_df['quantile'] == q]['return']
            if len(q_daily_ret) > 0:
                month_vol = q_daily_ret.std()  # 当月月波动率（日收益标准差）
                annual_vol = month_vol * np.sqrt(12)  # 年化波动率=月波动率×√12
            else:
                annual_vol = 0
            monthly_vol[f'Q{q}_annual_vol'] = annual_vol
        
        # 多空组合年化波动率（取Q5和Q1年化波动率的差值绝对值）
        long_short_annual_vol = abs(monthly_vol['Q5_annual_vol'] - monthly_vol['Q1_annual_vol'])
        
        # ==========================================================================
        # 计算3：各组夏普比率（严格按要求：年化收益率 / 年化波动率）
        # 年化收益率 = 当月月度收益率 × 12（单月年化，用于当月夏普计算）
        # ==========================================================================
        monthly_sharpe = {}  # 存储当月各组夏普比率
        for q in [1,5]:
            monthly_ret = monthly_return[f'Q{q}']
            annual_ret = monthly_ret * 12  # 单月收益率年化（简化计算，整体绩效会重新年化）
            annual_vol = monthly_vol[f'Q{q}_annual_vol']
            # 夏普比率=年化收益率/年化波动率（避免分母为0）
            monthly_sharpe[f'Q{q}_sharpe'] = annual_ret / annual_vol if annual_vol > 0 else np.nan
        
        # 多空组合夏普比率
        ls_annual_ret = long_short_return * 12  # 多空单月收益年化
        long_short_sharpe = ls_annual_ret / long_short_annual_vol if long_short_annual_vol > 0 else np.nan
        
        # 保存当月结果
        portfolio_results.append({
            'year_month': return_month,
            'factor': factor_name,
            'Q1_return': monthly_return['Q1'],  # 当月月度收益率
            'Q5_return': monthly_return['Q5'],
            'long_short_return': long_short_return,
            'Q1_annual_vol': monthly_vol['Q1_annual_vol'],  # 当月年化波动率（月波×√12）
            'Q5_annual_vol': monthly_vol['Q5_annual_vol'],
            'long_short_annual_vol': long_short_annual_vol,
            'Q1_sharpe': monthly_sharpe['Q1_sharpe'],  # 当月夏普比率（年化收益/年化波）
            'Q5_sharpe': monthly_sharpe['Q5_sharpe'],
            'long_short_sharpe': long_short_sharpe,
            'n_stocks': len(month_end_data),
            'n_trading_days': len(next_month_data['Trddt'].unique())
        })
    
    return pd.DataFrame(portfolio_results)

# 分别构建3个因子的多空组合
factors = ['MAX', 'Past_Perf', 'Volatility']
all_portfolio_results = []
for factor in factors:
    print(f"\n基于{factor}因子构建月度多空组合...")
    factor_results = construct_monthly_portfolios(df_processed, factor)
    all_portfolio_results.append(factor_results)
    print(f"  成功构建 {len(factor_results)} 个月的组合")

# 合并3个因子的结果
all_results = pd.concat(all_portfolio_results, ignore_index=True)

# ==============================================================================
#  Step 4: 整体绩效指标汇总（年化收益率/波动率/夏普比率，严格匹配要求）
# 整体年化收益率：基于所有月度收益累乘计算
# 整体年化波动率：基于所有月度收益标准差 × √12
# 整体夏普比率：整体年化收益率 / 整体年化波动率
# ==============================================================================
def calculate_overall_performance(results, factor_name):
    """计算单个因子组合的整体绩效指标（最终汇报用）"""
    factor_data = results[results['factor'] == factor_name]
    if len(factor_data) == 0:
        return None
    
    # 提取月度收益序列
    q1_monthly_ret = factor_data['Q1_return']
    q5_monthly_ret = factor_data['Q5_return']
    ls_monthly_ret = factor_data['long_short_return']
    n_months = len(factor_data)
    n_years = n_months / 12
    
    # 1. 整体年化收益率（月度收益累乘年化）
    def annualize_return(monthly_returns):
        total_return = (1 + monthly_returns).prod() - 1
        return (1 + total_return) ** (1/n_years) - 1 if n_years > 0 else 0
    
    # 2. 整体年化波动率（月度收益标准差 × √12，严格按要求）
    def annualize_volatility(monthly_returns):
        monthly_vol = monthly_returns.std()  # 月度收益标准差（整体月波动率）
        return monthly_vol * np.sqrt(12)  # 年化波动率=月波×√12
    
    # 3. 整体夏普比率（年化收益率 / 年化波动率，严格按要求）
    def calculate_sharpe(annual_return, annual_vol):
        return annual_return / annual_vol if annual_vol > 0 else np.nan
    
    # 计算各组整体绩效
    q1_ann_ret = annualize_return(q1_monthly_ret)
    q5_ann_ret = annualize_return(q5_monthly_ret)
    ls_ann_ret = annualize_return(ls_monthly_ret)
    
    q1_ann_vol = annualize_volatility(q1_monthly_ret)
    q5_ann_vol = annualize_volatility(q5_monthly_ret)
    ls_ann_vol = annualize_volatility(ls_monthly_ret)
    
    q1_sharpe = calculate_sharpe(q1_ann_ret, q1_ann_vol)
    q5_sharpe = calculate_sharpe(q5_ann_ret, q5_ann_vol)
    ls_sharpe = calculate_sharpe(ls_ann_ret, ls_ann_vol)
    
    # 汇总结果
    perf = {
        'factor': factor_name,
        'Q1_annual_return': q1_ann_ret,
        'Q5_annual_return': q5_ann_ret,
        'LS_annual_return': ls_ann_ret,
        'Q1_annual_vol': q1_ann_vol,
        'Q5_annual_vol': q5_ann_vol,
        'LS_annual_vol': ls_ann_vol,
        'Q1_sharpe': q1_sharpe,
        'Q5_sharpe': q5_sharpe,
        'LS_sharpe': ls_sharpe,
        'win_rate': (ls_monthly_ret > 0).mean(),
        'n_months': n_months,
        'start_date': factor_data['year_month'].min(),
        'end_date': factor_data['year_month'].max()
    }
    return perf

# 汇总3个因子的整体绩效（最终汇报核心结果）
performance_summary = []
for factor in factors:
    perf = calculate_overall_performance(all_results, factor)
    if perf:
        performance_summary.append(perf)
perf_df = pd.DataFrame(performance_summary)

# 打印最终绩效结果（清晰展示3个因子的年化收益/波动率/夏普比率）
print("\n" + "="*120)
print("3个因子多空组合最终绩效汇总（等权重，2015-2024）")
print("核心计算逻辑：年化波动率=月波动率×√12，夏普比率=年化收益率/年化波动率")
print("="*120)
print(f"{'因子':<15} {'组合类型':<20} {'年化收益率':<12} {'年化波动率':<12} {'夏普比率':<10} {'有效月数':<8}")
print("-"*120)
for _, row in perf_df.iterrows():
    factor = row['factor']
    # Q1（空头组）
    print(f"{factor:<15} {'Q1 (低因子)':<20} {row['Q1_annual_return']:>10.2%} {row['Q1_annual_vol']:>11.2%} {row['Q1_sharpe']:>9.2f} {row['n_months']:>8}")
    # Q5（多头组）
    print(f"{factor:<15} {'Q5 (高因子)':<20} {row['Q5_annual_return']:>10.2%} {row['Q5_annual_vol']:>11.2%} {row['Q5_sharpe']:>9.2f} {row['n_months']:>8}")
    # 多空组合（Q5-Q1）
    print(f"{factor:<15} {'多空组合':<20} {row['LS_annual_return']:>10.2%} {row['LS_annual_vol']:>11.2%} {row['LS_sharpe']:>9.2f} {row['n_months']:>8}")
    print("-"*120)

# 打印详细统计（补充多头/空头收益贡献对比）
print("\n【详细统计&收益贡献分析】")
for _, row in perf_df.iterrows():
    print(f"\n{row['factor']}因子：")
    print(f"  回测期间：{row['start_date']} 到 {row['end_date']}")
    print(f"  多空组合胜率：{row['win_rate']:.2%}")
    print(f"  多头（Q5）年化收益：{row['Q5_annual_return']:.2%} | 空头（Q1）年化收益：{row['Q1_annual_return']:.2%}")
    print(f"  收益贡献：{'多头贡献更大' if row['Q5_annual_return'] > abs(row['Q1_annual_return']) else '空头贡献更大'}")

# ==============================================================================
#  Step 5: 累计收益曲线绘制（3个组合与基准对比，对应原文档问题4）
# ==============================================================================
# 计算各组累计收益率 - 修复索引对齐问题
def calculate_cumulative_returns(df, column_name):
    """安全计算累积收益率，确保索引对齐"""
    result = df.copy()
    
    # 对每个因子单独计算
    for factor in factors:
        factor_mask = result['factor'] == factor
        factor_data = result[factor_mask].sort_values('year_month')
        
        if len(factor_data) > 0:
            # 计算累积收益率
            cumulative = (1 + factor_data[column_name]).cumprod()
            # 确保索引对齐
            result.loc[factor_mask, f'{column_name}_cumulative'] = cumulative.values
    
    return result

# 计算累积收益率
all_results = calculate_cumulative_returns(all_results, 'Q1_return')
all_results = calculate_cumulative_returns(all_results, 'Q5_return')
all_results = calculate_cumulative_returns(all_results, 'long_short_return')

# 绘制3个因子多空组合与基准的累计收益曲线
plt.figure(figsize=(14, 8))
colors = ['#1f77b4', '#ff7f0e', '#2ca02c']  # 3个因子对应颜色
for i, factor in enumerate(factors):
    factor_data = all_results[all_results['factor'] == factor].sort_values('year_month')
    
    # 确保有数据
    if len(factor_data) == 0:
        continue
        
    # 绘制因子多空组合曲线
    plt.plot(
        factor_data['year_month'].astype(str),
        factor_data['long_short_return_cumulative'],
        label=f'{factor}因子多空组合',
        color=colors[i],
        linewidth=2.5
    )

# 添加基准曲线（如果数据文件存在）
try:
    # 读取基准指数数据（1/2沪深300 + 1/2中证500，需自行准备月度收益率数据）
    # 假设benchmark_df包含'year_month'（Period类型）和'benchmark_monthly_return'字段
    benchmark_df = pd.read_excel('benchmark.xlsx')
    benchmark_df['year_month'] = pd.to_period(benchmark_df['year_month'])
    benchmark_df['benchmark_cumulative'] = (1 + benchmark_df['benchmark_monthly_return']).cumprod()
    
    # 绘制基准曲线
    plt.plot(
        benchmark_df['year_month'].astype(str),
        benchmark_df['benchmark_cumulative'],
        label='基准 (1/2沪深300 + 1/2中证500)',
        color='gray',
        linewidth=2,
        linestyle='--'
    )
except FileNotFoundError:
    print("\n基准数据文件未找到，仅绘制因子组合曲线")
except Exception as e:
    print(f"\n读取基准数据时出错：{e}")

plt.title('3个因子多空组合累计收益曲线（2015-2024）', fontsize=14, fontweight='bold')
plt.xlabel('日期', fontsize=12)
plt.ylabel('累计净值（初始=1）', fontsize=12)
plt.legend(fontsize=11, loc='best')
plt.grid(True, alpha=0.3)
plt.xticks(rotation=45)
plt.tight_layout()
plt.savefig('factor_portfolios_cumulative_returns.png', dpi=300, bbox_inches='tight')
print("\n累计收益曲线已保存为 'factor_portfolios_cumulative_returns.png'")
plt.show()

# ==============================================================================
#  Step 6: MAX因子流通市值权重组合（与等权重对比，对应原文档问题3）
# ==============================================================================
def construct_value_weighted_portfolio(df, factor_name='MAX'):
    """基于MAX因子构建流通市值权重多空组合，计算年化收益/波动率/夏普比率"""
    portfolio_results = []
    all_months = sorted(df['year_month'].unique())
    
    for i in range(1, len(all_months)):
        group_month = all_months[i-1]
        return_month = all_months[i]
        
        # 获取分组数据（含流通市值，字段名：Dsmvosd）
        month_end_data = df[df['year_month'] == group_month].groupby('Stkcd').last().reset_index()
        month_end_data = month_end_data[['Stkcd', factor_name, 'Dsmvosd']].dropna()
        if len(month_end_data) < 50:
            continue
        
        # 按MAX因子分成5组
        month_end_data['quantile'] = pd.qcut(
            month_end_data[factor_name], 5, labels=[1,2,3,4,5], duplicates='drop'
        )
        
        # 获取t+1月日度收益数据
        next_month_data = df[df['year_month'] == return_month][['Stkcd', 'Trddt', 'Dretwd']]
        if len(next_month_data) == 0:
            continue
        
        # 计算市值权重月度收益率
        monthly_return = {}
        for q in [1,5]:
            q_stocks = month_end_data[month_end_data['quantile'] == q]['Stkcd'].tolist()
            q_daily_data = next_month_data[next_month_data['Stkcd'].isin(q_stocks)]
            if len(q_daily_data) == 0:
                monthly_return[f'Q{q}'] = 0
                continue
            # 合并流通市值数据
            q_daily_data = pd.merge(q_daily_data, month_end_data[['Stkcd', 'Dsmvosd']], on='Stkcd')
            
            # 计算每日市值权重收益
            daily_weighted_ret = []
            for date in q_daily_data['Trddt'].unique():
                date_data = q_daily_data[q_daily_data['Trddt'] == date]
                total_cap = date_data['Dsmvosd'].sum()  # 当日该组总市值
                # 当日权重收益=Σ(个股日收益×个股市值/总市值)
                date_weighted_ret = (date_data['Dretwd'] * date_data['Dsmvosd'] / total_cap).sum()
                daily_weighted_ret.append(date_weighted_ret)
            
            # 月度收益率（日收益累乘）
            monthly_return[f'Q{q}'] = (1 + np.array(daily_weighted_ret)).prod() - 1
        
        # 多空组合月度收益
        long_short_return = monthly_return['Q5'] - monthly_return['Q1']
        
        # 计算年化波动率（月波动率×√12）
        monthly_vol = {}
        for q in [1,5]:
            q_stocks = month_end_data[month_end_data['quantile'] == q]['Stkcd'].tolist()
            q_daily_data = next_month_data[next_month_data['Stkcd'].isin(q_stocks)]
            q_daily_ret = q_daily_data.groupby('Trddt')['Dretwd'].mean()  # 日度等权收益（用于算波动率）
            if len(q_daily_ret) > 0:
                month_vol = q_daily_ret.std()
                monthly_vol[f'Q{q}_annual_vol'] = month_vol * np.sqrt(12)
            else:
                monthly_vol[f'Q{q}_annual_vol'] = 0
        long_short_annual_vol = abs(monthly_vol['Q5_annual_vol'] - monthly_vol['Q1_annual_vol'])
        
        # 计算夏普比率（年化收益率/年化波动率）
        ls_annual_ret = long_short_return * 12
        long_short_sharpe = ls_annual_ret / long_short_annual_vol if long_short_annual_vol > 0 else np.nan
        
        # 保存结果
        portfolio_results.append({
            'year_month': return_month,
            'Q1_return': monthly_return['Q1'],
            'Q5_return': monthly_return['Q5'],
            'long_short_return': long_short_return,
            'long_short_annual_vol': long_short_annual_vol,
            'long_short_sharpe': long_short_sharpe,
            'weight_type': 'value_weighted'
        })
    
    return pd.DataFrame(portfolio_results)

# 构建MAX因子市值权重组合
print("\n【MAX因子权重对比】")
print("基于MAX因子构建流通市值权重多空组合...")
value_weighted_results = construct_value_weighted_portfolio(df_processed)
print(f"  成功构建 {len(value_weighted_results)} 个月的组合")

# 计算MAX因子等权重 vs 市值权重的整体绩效
def compare_weight_performance(equal_weight_data, value_weight_data):
    """对比等权重和市值权重的年化收益/波动率/夏普比率"""
    # 等权重数据（MAX因子）
    eq_monthly_ret = equal_weight_data['long_short_return']
    # 市值权重数据
    val_monthly_ret = value_weight_data['long_short_return']
    
    # 计算年化收益率（累乘）
    def ann_ret(monthly_ret):
        n_years = len(monthly_ret)/12
        total_ret = (1 + monthly_ret).prod() - 1
        return (1 + total_ret)**(1/n_years) - 1 if n_years>0 else 0
    
    # 计算年化波动率（月波×√12）
    def ann_vol(monthly_ret):
        return monthly_ret.std() * np.sqrt(12) if len(monthly_ret)>0 else 0
    
    # 计算夏普比率
    def sharpe(ann_ret, ann_vol):
        return ann_ret/ann_vol if ann_vol>0 else np.nan
    
    # 对比结果
    eq_ann_ret = ann_ret(eq_monthly_ret)
    val_ann_ret = ann_ret(val_monthly_ret)
    eq_ann_vol = ann_vol(eq_monthly_ret)
    val_ann_vol = ann_vol(val_monthly_ret)
    eq_sharpe = sharpe(eq_ann_ret, eq_ann_vol)
    val_sharpe = sharpe(val_ann_ret, val_ann_vol)
    
    return {
        'weight_type': ['等权重', '流通市值权重'],
        'annual_return': [eq_ann_ret, val_ann_ret],
        'annual_volatility': [eq_ann_vol, val_ann_vol],
        'sharpe_ratio': [eq_sharpe, val_sharpe],
        'n_months': [len(eq_monthly_ret), len(val_monthly_ret)]
    }

# 提取MAX因子等权重数据
max_equal_weight_data = all_results[all_results['factor'] == 'MAX']
# 对比两者绩效
if len(value_weighted_results) > 0:
    weight_compare = compare_weight_performance(max_equal_weight_data, value_weighted_results)
    weight_compare_df = pd.DataFrame(weight_compare)

    # 打印对比结果
    print("\nMAX因子多空组合：等权重 vs 流通市值权重")
    print("="*100)
    print(f"{'权重类型':<15} {'年化收益率':<12} {'年化波动率':<12} {'夏普比率':<10} {'有效月数':<8}")
    print("-"*100)
    for _, row in weight_compare_df.iterrows():
        print(f"{row['weight_type']:<15} {row['annual_return']:>10.2%} {row['annual_volatility']:>11.2%} {row['sharpe_ratio']:>9.2f} {row['n_months']:>8}")
    print("-"*100)
    
    # 确定哪种权重表现更好
    if len(weight_compare_df) >= 2:
        better_weight = '等权重' if weight_compare_df.loc[0, 'annual_return'] > weight_compare_df.loc[1, 'annual_return'] else '流通市值权重'
        print(f"\n结论：{better_weight}带来的收益更高")
        print("原因解释：等权重组合更分散，避免了大市值股票的权重集中风险，而MAX因子在中小市值股票中有效性更强；市值权重组合受大市值股票波动影响较大，削弱了因子收益。")
else:
    print("\n警告：流通市值权重组合构建失败或数据不足，跳过权重对比分析。")

# ==============================================================================
#  Step 7: 保存结果到Excel
# ==============================================================================
print("\n" + "="*80)
print("保存结果到Excel文件...")

# 创建Excel写入器
output_file = 'factor_analysis_results.xlsx'
with pd.ExcelWriter(output_file, engine='openpyxl') as writer:
    # 保存因子数据
    df_processed.to_excel(writer, sheet_name='因子数据', index=False)
    
    # 保存月度组合结果
    all_results.to_excel(writer, sheet_name='月度组合结果', index=False)
    
    # 保存绩效汇总
    perf_df.to_excel(writer, sheet_name='绩效汇总', index=False)
    
    # 保存权重对比结果
    if 'weight_compare_df' in locals():
        weight_compare_df.to_excel(writer, sheet_name='权重对比', index=False)

print(f"✓ 结果已保存到 '{output_file}'")
print("\n分析完成！")