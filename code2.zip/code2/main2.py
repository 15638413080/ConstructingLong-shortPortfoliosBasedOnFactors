import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import warnings
warnings.filterwarnings('ignore')


plt.rcParams['font.family'] = 'WenQuanYi Micro Hei'
plt.rcParams['font.size'] = 12
plt.rcParams['axes.unicode_minus'] = False


# ==============================================================================
#  Step 1: 数据整合（合并沪深300+中证500分时段收益+权重数据）
# ==============================================================================
def load_all_data():
    """加载并合并所有数据：沪深300/中证500分时段收益 + 成分股权重"""
    # 1.1 加载权重数据（沪深300+中证500）
    def load_weight(file_path):
        """读取成分股权重数据"""
        try:
            weight_df = pd.read_excel(file_path)
            print(f"读取权重文件 {file_path}，列名：{weight_df.columns.tolist()}")
            
            # 检查可能的列名组合
            col_names = weight_df.columns.tolist()
            
            # 股票代码列的可能名称
            code_col = None
            possible_code_cols = ['Constituent Code', '成份券代码', '证券代码', '股票代码', 'Stkcd']
            for col in possible_code_cols:
                if col in col_names:
                    code_col = col
                    break
            if code_col is None and len(col_names) >= 5:
                # 尝试第五列（基于截图结构）
                code_col = col_names[4]
            
            # 权重列的可能名称
            weight_col = None
            possible_weight_cols = ['weight(%)', '权重 (%)', '权重', 'weight', '权重(%)']
            for col in possible_weight_cols:
                if col in col_names:
                    weight_col = col
                    break
            if weight_col is None and len(col_names) >= 9:
                # 尝试第九列（基于截图结构）
                weight_col = col_names[8]
            
            if code_col is None or weight_col is None:
                print(f"警告：无法找到必要的列，使用默认列名")
                print(f"文件列：{col_names}")
                # 使用前两列作为股票代码和权重
                if len(col_names) >= 2:
                    code_col = col_names[0]
                    weight_col = col_names[1]
                else:
                    return pd.DataFrame()
            
            print(f"使用列：股票代码={code_col}, 权重={weight_col}")
            
            weight_df = weight_df[[code_col, weight_col]].copy()
            weight_df.columns = ['Constituent_Code', 'Weight_Pct']
            
            # 清理数据
            weight_df = weight_df.dropna()
            weight_df['Stkcd_str'] = weight_df['Constituent_Code'].astype(str).str.zfill(6)  # 6位股票代码
            weight_df['MktCap_Weight'] = pd.to_numeric(weight_df['Weight_Pct'], errors='coerce') / 100  # 权重转小数
            
            return weight_df[['Stkcd_str', 'MktCap_Weight']].drop_duplicates()
            
        except Exception as e:
            print(f"读取权重文件 {file_path} 出错：{e}")
            return pd.DataFrame()
    
    # 尝试加载权重数据
    print("正在加载权重数据...")
    hs300_weight = load_weight('Appendix1 000300closeweight.xls')  # 沪深300权重
    zz500_weight = load_weight('Appendix2 000905closeweight.xls')  # 中证500权重
    
    if len(hs300_weight) > 0:
        print(f"沪深300权重记录数：{len(hs300_weight)}")
    if len(zz500_weight) > 0:
        print(f"中证500权重记录数：{len(zz500_weight)}")
    
    # 合并权重数据
    if len(hs300_weight) > 0 or len(zz500_weight) > 0:
        total_weight = pd.concat([hs300_weight, zz500_weight], ignore_index=True)
        total_weight = total_weight.drop_duplicates(subset='Stkcd_str', keep='first')
        print(f"合并后权重记录数：{len(total_weight)}")
    else:
        print("警告：权重数据为空，将使用等权重")
        total_weight = pd.DataFrame(columns=['Stkcd_str', 'MktCap_Weight'])
    
    # 1.2 加载分时段收益数据
    print("\n正在加载收益数据...")
    try:
        # 读取TRD_Dalyr.xlsx文件
        df = pd.read_excel('TRD_Dalyr.xlsx')
        print(f"读取收益数据，列名：{df.columns.tolist()}")
        print(f"数据形状：{df.shape}")
        
        # 检查列名并统一命名
        col_mapping = {}
        for col in df.columns:
            if '代码' in str(col) or 'Stkcd' in str(col):
                col_mapping[col] = 'Stkcd'
            elif '日期' in str(col) or 'Trddt' in str(col) or 'date' in str(col).lower():
                col_mapping[col] = 'Trddt'
            elif '回报' in str(col) or '收益' in str(col) or 'Dretwd' in str(col) or 'return' in str(col).lower():
                col_mapping[col] = 'Dretwd'
            elif '市值' in str(col) or 'Dsmvgsd' in str(col) or 'mktcap' in str(col).lower():
                col_mapping[col] = 'Dsmvgsd'
        
        # 重命名列
        df = df.rename(columns=col_mapping)
        print(f"重命名后列名：{df.columns.tolist()}")
        
        # 确保必要的列存在
        required_cols = ['Stkcd', 'Trddt', 'Dretwd']
        for col in required_cols:
            if col not in df.columns:
                print(f"错误：缺少必要列 {col}")
                return None
        
        # 添加市场类型和时段信息
        # 根据实际情况可能需要调整，这里假设全部数据都是沪深300+中证500
        df['market_type'] = 'HS300'  # 先全部标记为沪深300，后续根据实际情况调整
        df['time_period'] = '2015-2024'  # 简化处理，不分时段
        
    except Exception as e:
        print(f"读取收益数据出错：{e}")
        return None
    
    # 1.3 数据预处理
    df['Trddt'] = pd.to_datetime(df['Trddt'], errors='coerce')
    df = df.dropna(subset=['Trddt'])
    df['Stkcd_str'] = df['Stkcd'].astype(str).str.zfill(6)  # 统一股票代码格式
    df['year_month'] = df['Trddt'].dt.to_period('M')  # 年月标记
    
    # 1.4 合并权重数据
    if len(total_weight) > 0:
        print("合并权重数据...")
        all_data = pd.merge(df, total_weight, on='Stkcd_str', how='left')
        print(f"合并后数据形状：{all_data.shape}")
        print(f"权重缺失比例：{(all_data['MktCap_Weight'].isna().sum() / len(all_data)):.2%}")
    else:
        all_data = df.copy()
        all_data['MktCap_Weight'] = np.nan
    
    # 权重缺失填充：按年月分组，缺失权重=1/该组股票数量
    if 'MktCap_Weight' in all_data.columns:
        monthly_stock_count = all_data.groupby('year_month')['Stkcd_str'].nunique()
        all_data['monthly_stock_count'] = all_data['year_month'].map(monthly_stock_count)
        mask = all_data['MktCap_Weight'].isna()
        all_data.loc[mask, 'MktCap_Weight'] = 1 / all_data.loc[mask, 'monthly_stock_count']
    
    print(f"数据整合完成，总记录数：{len(all_data)}")
    return all_data

# 加载所有数据
print("="*80)
print("开始加载数据...")
df = load_all_data()

if df is None:
    print("数据加载失败，程序退出")
    exit()

print(f"\n数据整合完成，总记录数：{len(df)}")
print(f"数据期间：{df['Trddt'].min()} 到 {df['Trddt'].max()}")
print(f"股票数量：{df['Stkcd_str'].nunique()}")

# ==============================================================================
#  Step 2: 计算MAX因子
# ==============================================================================
def calculate_max_factor(df):
    """按股票计算MAX因子（过去20日最高日收益）"""
    print("\n计算MAX因子...")
    df = df.sort_values(['Stkcd_str', 'Trddt'])
    
    def calc_max_per_stock(group):
        group['MAX'] = group['Dretwd'].rolling(window=20, min_periods=15).max()
        return group
    
    df_with_max = df.groupby('Stkcd_str').apply(calc_max_per_stock).reset_index(drop=True)
    print(f"MAX因子计算完成，有效记录数：{df_with_max['MAX'].notna().sum()}")
    return df_with_max

df_processed = calculate_max_factor(df)

# ==============================================================================
#  Step 3: 构建多空组合（等权重+流通市值权重）
# ==============================================================================
def construct_portfolios(df):
    """构建MAX因子多空组合，输出等权重/市值权重对比结果"""
    print("\n构建多空组合...")
    portfolio_results = []
    
    all_months = sorted(df['year_month'].unique())
    print(f"总月份数：{len(all_months)}")
    
    for i in range(1, len(all_months)):
        group_month = all_months[i-1]
        return_month = all_months[i]
        
        if i % 12 == 0 or i == len(all_months) - 1:
            print(f"处理进度：{i}/{len(all_months)} 个月")
        
        # 3.1 月末分组数据（MAX因子+权重）
        month_end_data = df[df['year_month'] == group_month].groupby('Stkcd_str').last().reset_index()
        month_end_data = month_end_data[['Stkcd_str', 'MAX']].dropna()
        
        if len(month_end_data) < 50:
            continue
        
        # 3.2 按MAX因子分5组
        try:
            month_end_data['quantile'] = pd.qcut(
                month_end_data['MAX'], 5, labels=[1,2,3,4,5], duplicates='drop'
            )
        except ValueError as e:
            print(f"月份 {group_month} 分组失败：{e}")
            continue
        
        # 3.3 下月收益数据
        next_month_data = df[df['year_month'] == return_month][['Stkcd_str', 'Trddt', 'Dretwd']]
        if len(next_month_data) == 0:
            continue
        
        # 3.4 计算等权重/市值权重的Q1/Q5收益
        for weight_type in ['equal', 'market_cap']:
            monthly_return = {}
            
            # 获取权重数据
            if weight_type == 'market_cap' and 'MktCap_Weight' in df.columns:
                # 合并市值权重
                month_end_weight = df[df['year_month'] == group_month][['Stkcd_str', 'MktCap_Weight']].drop_duplicates()
                month_end_data_weighted = pd.merge(month_end_data, month_end_weight, on='Stkcd_str', how='left')
                month_end_data_weighted['MktCap_Weight'] = month_end_data_weighted['MktCap_Weight'].fillna(1)
                
                # 合并下月权重数据
                next_month_weight = df[df['year_month'] == return_month][['Stkcd_str', 'MktCap_Weight']].drop_duplicates()
                next_month_data_weighted = pd.merge(next_month_data, next_month_weight, on='Stkcd_str', how='left')
                next_month_data_weighted['MktCap_Weight'] = next_month_data_weighted['MktCap_Weight'].fillna(1)
            else:
                # 等权重
                month_end_data_weighted = month_end_data.copy()
                month_end_data_weighted['Weight'] = 1.0
                next_month_data_weighted = next_month_data.copy()
                next_month_data_weighted['Weight'] = 1.0
                weight_col = 'Weight'
            
            for q in [1,5]:
                q_stocks = month_end_data_weighted[month_end_data_weighted['quantile'] == q]['Stkcd_str'].tolist()
                if weight_type == 'equal':
                    q_daily_data = next_month_data[next_month_data['Stkcd_str'].isin(q_stocks)]
                    if len(q_daily_data) == 0:
                        monthly_return[f'Q{q}'] = 0
                        continue
                    # 等权重日收益
                    daily_ret = q_daily_data.groupby('Trddt')['Dretwd'].mean()
                else:
                    # 市值权重
                    q_daily_data = next_month_data_weighted[next_month_data_weighted['Stkcd_str'].isin(q_stocks)]
                    if len(q_daily_data) == 0:
                        monthly_return[f'Q{q}'] = 0
                        continue
                    
                    # 计算每日市值权重收益
                    daily_ret_list = []
                    for date in q_daily_data['Trddt'].unique():
                        date_data = q_daily_data[q_daily_data['Trddt'] == date]
                        total_weight = date_data['MktCap_Weight'].sum()
                        if total_weight == 0:
                            daily_ret_list.append(0)
                        else:
                            weighted_ret = (date_data['Dretwd'] * date_data['MktCap_Weight']).sum() / total_weight
                            daily_ret_list.append(weighted_ret)
                    
                    daily_ret = pd.Series(daily_ret_list, index=q_daily_data['Trddt'].unique())
                
                if len(daily_ret) > 0:
                    monthly_return[f'Q{q}'] = (1 + daily_ret).prod() - 1
                else:
                    monthly_return[f'Q{q}'] = 0
            
            # 多空收益
            long_short_return = monthly_return['Q5'] - monthly_return['Q1']
            
            portfolio_results.append({
                'year_month': return_month,
                'weight_type': weight_type,
                'Q1_return': monthly_return['Q1'],
                'Q5_return': monthly_return['Q5'],
                'long_short_return': long_short_return
            })
    
    return pd.DataFrame(portfolio_results)

# 构建组合
portfolio_df = construct_portfolios(df_processed)
print(f"\n组合构建完成，有效记录数：{len(portfolio_df)}")

# ==============================================================================
#  Step 4: 绩效计算与对比
# ==============================================================================
def calculate_performance(portfolio_df):
    """计算各维度绩效指标"""
    print("\n计算绩效指标...")
    perf_results = []
    
    for weight_type in ['equal', 'market_cap']:
        sub_df = portfolio_df[portfolio_df['weight_type'] == weight_type]
        if len(sub_df) == 0:
            continue
        
        ls_returns = sub_df['long_short_return']
        n_months = len(ls_returns)
        n_years = n_months / 12
        
        # 年化收益率
        total_ret = (1 + ls_returns).prod() - 1
        annual_return = (1 + total_ret) ** (1/n_years) - 1 if n_years > 0 else 0
        
        # 年化波动率（月标准差×√12）
        annual_vol = ls_returns.std() * np.sqrt(12)
        
        # 夏普比率
        sharpe = annual_return / annual_vol if annual_vol > 0 else np.nan
        
        # 胜率
        win_rate = (ls_returns > 0).mean()
        
        perf_results.append({
            '权重类型': '等权重' if weight_type == 'equal' else '流通市值权重',
            '年化收益率': annual_return,
            '年化波动率': annual_vol,
            '夏普比率': sharpe,
            '胜率': win_rate,
            '有效月数': n_months,
            '起始月份': sub_df['year_month'].min(),
            '结束月份': sub_df['year_month'].max()
        })
    
    return pd.DataFrame(perf_results)

# 计算绩效
perf_df = calculate_performance(portfolio_df)

# 打印绩效结果
print("\n" + "="*120)
print("MAX因子多空组合绩效对比")
print("="*120)
if len(perf_df) > 0:
    # 格式化输出
    formatted_df = perf_df.copy()
    formatted_df['年化收益率'] = formatted_df['年化收益率'].apply(lambda x: f"{x:.2%}")
    formatted_df['年化波动率'] = formatted_df['年化波动率'].apply(lambda x: f"{x:.2%}")
    formatted_df['夏普比率'] = formatted_df['夏普比率'].apply(lambda x: f"{x:.2f}")
    formatted_df['胜率'] = formatted_df['胜率'].apply(lambda x: f"{x:.2%}")
    
    print(formatted_df.to_string(index=False))
else:
    print("无绩效数据")

# ==============================================================================
#  Step 5: 可视化对比
# ==============================================================================
print("\n生成可视化图表...")
plt.figure(figsize=(14, 8))

for weight_type in ['equal', 'market_cap']:
    sub_df = portfolio_df[portfolio_df['weight_type'] == weight_type].sort_values('year_month')
    if len(sub_df) == 0:
        continue
    
    # 计算累计收益
    sub_df['cumulative_return'] = (1 + sub_df['long_short_return']).cumprod()
    
    # 绘图
    label = '等权重' if weight_type == 'equal' else '流通市值权重'
    color = '#1f77b4' if weight_type == 'equal' else '#ff7f0e'
    linestyle = '-' if weight_type == 'equal' else '--'
    
    plt.plot(
        sub_df['year_month'].astype(str),
        sub_df['cumulative_return'],
        label=label,
        linewidth=2.5,
        color=color,
        linestyle=linestyle
    )

plt.title('MAX因子多空组合累计收益对比（2015-2024）', fontsize=14, fontweight='bold')
plt.xlabel('日期', fontsize=12)
plt.ylabel('累计净值（初始=1）', fontsize=12)
plt.legend(fontsize=12, loc='best')
plt.grid(True, alpha=0.3)
plt.xticks(rotation=45)
plt.tight_layout()

# 保存图表
plt.savefig('MAX_factor_portfolio_comparison.png', dpi=300, bbox_inches='tight')
print("图表已保存为 'MAX_factor_portfolio_comparison.png'")
plt.show()

# ==============================================================================
#  Step 6: 核心结论与解释
# ==============================================================================
print("\n" + "="*120)
print("核心结论与解释")
print("="*120)

if len(perf_df) >= 2:
    equal_perf = perf_df[perf_df['权重类型'] == '等权重'].iloc[0]
    cap_perf = perf_df[perf_df['权重类型'] == '流通市值权重'].iloc[0]
    
    print(f"1. 整体收益对比：")
    print(f"   等权重组合年化收益率：{equal_perf['年化收益率']:.2%}")
    print(f"   流通市值权重组合年化收益率：{cap_perf['年化收益率']:.2%}")
    
    if equal_perf['年化收益率'] > cap_perf['年化收益率']:
        print(f"   → 等权重组合表现更优，年化收益率高出 {(equal_perf['年化收益率'] - cap_perf['年化收益率']):.2%}")
    else:
        print(f"   → 流通市值权重组合表现更优，年化收益率高出 {(cap_perf['年化收益率'] - equal_perf['年化收益率']):.2%}")
    
    print(f"\n2. 风险调整后收益（夏普比率）：")
    print(f"   等权重组合夏普比率：{equal_perf['夏普比率']:.2f}")
    print(f"   流通市值权重组合夏普比率：{cap_perf['夏普比率']:.2f}")
    
    print(f"\n3. 胜率对比：")
    print(f"   等权重组合胜率：{equal_perf['胜率']:.2%}")
    print(f"   流通市值权重组合胜率：{cap_perf['胜率']:.2%}")
    
    print(f"\n4. 结论解释：")
    if equal_perf['年化收益率'] > cap_perf['年化收益率']:
        print("   MAX因子（过去20日最高收益）在中小市值股票中表现更显著，等权重组合能够更均匀地捕捉所有股票的因子收益。")
        print("   流通市值权重组合向大市值股票倾斜，而大市值股票的MAX因子效应较弱，因此整体收益较低。")
    else:
        print("   MAX因子在大市值股票中表现更好，流通市值权重组合能够聚焦于有效股票，获得更高收益。")
    
    print(f"\n5. 回测期间：{perf_df['起始月份'].iloc[0]} 至 {perf_df['结束月份'].iloc[0]}")
    print(f"   有效月份数：{perf_df['有效月数'].iloc[0]} 个月")
    
else:
    print("无法进行完整的权重对比分析，可能原因：")
    print("1. 权重数据加载失败")
    print("2. 市值权重组合构建失败")
    print("3. 数据量不足")

# ==============================================================================
#  Step 7: 保存结果到Excel
# ==============================================================================
print("\n" + "="*80)
print("保存结果到Excel文件...")

try:
    output_file = 'MAX_factor_analysis_results.xlsx'
    with pd.ExcelWriter(output_file, engine='openpyxl') as writer:
        # 保存原始数据（前1000行）
        df.head(1000).to_excel(writer, sheet_name='原始数据示例', index=False)
        
        # 保存因子数据（前1000行）
        if 'MAX' in df_processed.columns:
            df_processed.head(1000).to_excel(writer, sheet_name='因子数据示例', index=False)
        
        # 保存组合结果
        portfolio_df.to_excel(writer, sheet_name='月度组合结果', index=False)
        
        # 保存绩效汇总
        perf_df.to_excel(writer, sheet_name='绩效汇总', index=False)
    
    print(f"✓ 结果已保存到 '{output_file}'")
    
except Exception as e:
    print(f"保存Excel文件时出错：{e}")

print("\n分析完成！")